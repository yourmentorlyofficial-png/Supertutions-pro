// SuperTutions Pro core configuration.
// This file contains public configuration only.
// Never place passwords, service-account credentials, or private API keys here.

export const CONFIG = Object.freeze({
  appName: "SuperTutions",

  // Development Apps Script endpoint supplied for this project.
  apiBaseUrl:
    "https://script.google.com/macros/s/AKfycbxHBo4YKTwR_VW5DKl2Ez23kW46PXaL1270DgZbeCvCp1PY7EEAklTD1PJNZSL5-znu/exec",

  apiVersion: "v1",

  storage: Object.freeze({
    databaseName: "supertutions",
    databaseVersion: 1,
    sessionStore: "session",
    cacheStore: "cache",
    outboxStore: "outbox"
  }),

  sync: Object.freeze({
    retryLimit: 5,
    retryBaseDelayMs: 1000
  })
});
