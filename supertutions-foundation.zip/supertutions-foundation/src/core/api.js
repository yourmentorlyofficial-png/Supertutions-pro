import { CONFIG } from "./config.js";
import { getSessionToken } from "./session.js";

function makeRequestId() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function request(action, payload = {}, options = {}) {
  const {
    authenticated = true,
    method = "POST",
    signal
  } = options;

  const body = {
    action,
    apiVersion: CONFIG.apiVersion,
    requestId: makeRequestId(),
    ...payload
  };

  if (authenticated) {
    const sessionToken = await getSessionToken();

    if (!sessionToken) {
      const error = new Error("Authentication required.");
      error.code = "AUTH_REQUIRED";
      throw error;
    }

    body.sessionToken = sessionToken;
  }

  const response = await fetch(CONFIG.apiBaseUrl, {
    method,
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify(body),
    signal
  });

  if (!response.ok) {
    const error = new Error(`API request failed: HTTP ${response.status}`);
    error.code = `HTTP_${response.status}`;
    throw error;
  }

  const result = await response.json();

  if (!result.ok) {
    const error = new Error(
      result.error?.message || "SuperTutions API request failed."
    );
    error.code = result.error?.code || "API_ERROR";
    error.requestId = result.requestId;
    throw error;
  }

  return result.data;
}

export async function login(email, password, options = {}) {
  return request(
    "auth.login",
    { email, password },
    { ...options, authenticated: false }
  );
}

export async function refreshSession(options = {}) {
  const sessionToken = await getSessionToken();

  if (!sessionToken) {
    const error = new Error("No session to refresh.");
    error.code = "AUTH_REQUIRED";
    throw error;
  }

  return request(
    "auth.refresh",
    { sessionToken },
    { ...options, authenticated: false }
  );
}

export async function logout(options = {}) {
  return request(
    "auth.logout",
    {},
    { ...options, authenticated: true }
  );
}

export async function getCurrentUser(options = {}) {
  return request("auth.me", {}, options);
}

export async function apiAction(action, payload = {}, options = {}) {
  return request(action, payload, options);
}
