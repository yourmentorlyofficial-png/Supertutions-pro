// Core bootstrap entry point for the future rebuilt app shell.

import { getSession } from "./session.js";
import { flushOutbox } from "./sync.js";

export async function bootstrapSuperTutions() {
  const session = await getSession();

  // Sync queued offline mutations when possible.
  await flushOutbox();

  return {
    authenticated: Boolean(session),
    user: session?.user ?? null
  };
}
