// Offline mutation outbox.
// This does not send anything until the backend action exists.

import { CONFIG } from "./config.js";
import { apiAction } from "./api.js";
import { getAll, put, remove } from "./storage.js";

function makeMutationId() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export async function queueMutation(action, payload) {
  const mutation = {
    mutationId: makeMutationId(),
    action,
    payload,
    status: "queued",
    attempts: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  await put(CONFIG.storage.outboxStore, mutation);
  return mutation;
}

export async function getPendingMutations() {
  const all = await getAll(CONFIG.storage.outboxStore);

  return all
    .filter(item => item.status === "queued" || item.status === "failed")
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function flushOutbox() {
  if (!navigator.onLine) {
    return { synced: 0, skipped: true };
  }

  const pending = await getPendingMutations();
  let synced = 0;

  for (const mutation of pending) {
    if (mutation.attempts >= CONFIG.sync.retryLimit) continue;

    mutation.status = "sending";
    mutation.attempts += 1;
    mutation.updatedAt = new Date().toISOString();
    await put(CONFIG.storage.outboxStore, mutation);

    try {
      await apiAction(
        mutation.action,
        {
          mutationId: mutation.mutationId,
          ...mutation.payload
        }
      );

      await remove(
        CONFIG.storage.outboxStore,
        mutation.mutationId
      );

      synced += 1;
    } catch (error) {
      mutation.status = "failed";
      mutation.lastError = {
        code: error.code || "UNKNOWN",
        message: error.message || "Unknown error"
      };
      mutation.updatedAt = new Date().toISOString();
      await put(CONFIG.storage.outboxStore, mutation);
    }
  }

  return { synced, skipped: false };
}

window.addEventListener("online", () => {
  flushOutbox().catch(console.error);
});
