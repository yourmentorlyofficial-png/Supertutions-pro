// Session state.
// This stores a backend-issued session token in IndexedDB so the login can
// survive app restarts without pretending that a boolean localStorage flag
// is authentication.

import { CONFIG } from "./config.js";
import { get, put, remove } from "./storage.js";

const SESSION_KEY = "current";

export async function saveSession(session) {
  if (!session?.sessionToken || !session?.user?.id) {
    throw new Error("Invalid session payload.");
  }

  await put(CONFIG.storage.sessionStore, {
    key: SESSION_KEY,
    ...session,
    savedAt: new Date().toISOString()
  });
}

export async function getSession() {
  return get(CONFIG.storage.sessionStore, SESSION_KEY);
}

export async function clearSession() {
  await remove(CONFIG.storage.sessionStore, SESSION_KEY);
}

export async function getSessionToken() {
  const session = await getSession();

  if (!session) return null;

  if (session.expiresAt) {
    const expiresAt = Date.parse(session.expiresAt);

    if (Number.isFinite(expiresAt) && expiresAt <= Date.now()) {
      await clearSession();
      return null;
    }
  }

  return session.sessionToken;
}

export async function isAuthenticated() {
  return Boolean(await getSessionToken());
}
