# SuperTutions Pro Foundation

This folder is the non-destructive foundation for the next rebuild of SuperTutions Pro.

## Important

Do **not** replace the current `index.html`, `app.js`, `manifest.json`, or `service-worker.js` yet.

This foundation is intentionally separated so the existing prototype keeps working while the real application architecture is built and tested.

## Put this folder at

```text
Supertutions-pro/
└── foundation/
    ├── docs/
    └── src/
```

## What this foundation establishes

- Real authentication contract, without pretending `localStorage === true` is authentication.
- Student/teacher role model.
- Google Apps Script API boundary.
- IndexedDB session/cache foundation.
- Offline mutation outbox with idempotency keys.
- A single place for app configuration.
- Clear data contracts for Google Sheets.
- Installability/offline rules.
- Security rules for the production build.

## Next implementation step

Build the actual Apps Script authentication endpoints against the contract in:

`foundation/docs/API-CONTRACT.md`

Then connect the new login UI to `foundation/src/core/api.js` and `foundation/src/core/session.js`.

## Security note

Never put a Google service-account credential, private API key, or Sheet edit credential into frontend JavaScript. The browser talks to the Apps Script web app; Apps Script performs privileged Sheet operations server-side.
