# SuperTutions API Contract v1

Base URL is configured in `src/core/config.js`.

The current Google Apps Script URL is the development endpoint supplied for the project. The frontend must not assume an endpoint exists until the Apps Script backend implements it.

## JSON response envelope

Success:

```json
{
  "ok": true,
  "data": {},
  "requestId": "req_..."
}
```

Failure:

```json
{
  "ok": false,
  "error": {
    "code": "AUTH_INVALID_CREDENTIALS",
    "message": "Invalid email or password."
  },
  "requestId": "req_..."
}
```

## Planned actions

### POST login

```json
{
  "action": "auth.login",
  "email": "student@example.com",
  "password": "..."
}
```

Response:

```json
{
  "ok": true,
  "data": {
    "sessionToken": "...",
    "expiresAt": "2026-08-16T12:00:00.000Z",
    "user": {
      "id": "stu_001",
      "role": "student",
      "name": "Student Name",
      "classId": "batch_001"
    }
  }
}
```

### POST session refresh

```json
{
  "action": "auth.refresh",
  "sessionToken": "..."
}
```

### POST logout

```json
{
  "action": "auth.logout",
  "sessionToken": "..."
}
```

### GET current user

```json
{
  "action": "auth.me",
  "sessionToken": "..."
}
```

## Data actions

Future actions follow this naming style:

- `student.dashboard`
- `student.homework.list`
- `student.quiz.list`
- `student.quiz.submit`
- `student.attendance`
- `teacher.dashboard`
- `teacher.students`
- `teacher.attendance.mark`
- `teacher.homework.create`
- `teacher.quiz.create`
- `teacher.announcements.create`

## Mutation rules

Every mutation should accept:

```json
{
  "mutationId": "uuid",
  "action": "...",
  "payload": {}
}
```

The server should return the same `mutationId` so the client can mark the outbox item as synchronized.

## Authentication errors

Use stable codes:

- `AUTH_REQUIRED`
- `AUTH_INVALID_CREDENTIALS`
- `AUTH_SESSION_EXPIRED`
- `AUTH_FORBIDDEN`
- `AUTH_ACCOUNT_DISABLED`

## Important

Passwords are never stored in Google Sheets in plaintext.

For a real production system, credential verification must happen server-side. If Google Apps Script is used for the initial backend, the password-verification design must be implemented carefully before real users are onboarded.
