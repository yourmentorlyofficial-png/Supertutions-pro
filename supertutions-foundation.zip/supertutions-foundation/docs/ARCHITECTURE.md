# SuperTutions Pro Architecture

## Product

SuperTutions Pro is a tuition-class operating system for students and teachers.

The experience should feel:
- calm and precise like a premium Apple product
- motivating and feedback-rich like a language-learning app
- unmistakably SuperTutions in its terminology, visuals, data, and workflows

The goal is not to imitate another product. Interaction patterns can be inspired by good products, but the visual system and workflows are SuperTutions-specific.

## Runtime layers

```text
┌─────────────────────────────────────────────┐
│              SuperTutions UI                │
│  Student experience  │  Teacher experience  │
└──────────────────────┬──────────────────────┘
                       │
                Core application
             auth / API / storage / sync
                       │
        ┌──────────────┴──────────────┐
        │                             │
   Online path                  Offline path
        │                             │
 Google Apps Script          IndexedDB cache
        │                     + mutation outbox
        │                             │
 Google Sheets               sync when online
```

## Source of truth

Google Sheets is the initial operational source of truth.

The frontend must never assume that a successful button animation means a write succeeded. A mutation has one of these states:

- `queued`
- `sending`
- `synced`
- `failed`
- `conflict`

## Authentication

The browser receives a short-lived session after the backend verifies credentials.

The client remembers the session using IndexedDB. The client does not decide a user's role by itself.

Every protected API request carries the session token. The Apps Script backend validates it and determines the user's role from server-side data.

## Roles

### Student

Can access only:
- own profile
- enrolled classes
- own attendance
- assigned homework
- own quiz attempts/results
- own progress
- announcements intended for their class

### Teacher

Can access only:
- their assigned classes
- students in those classes
- class attendance
- homework they own/assigned
- quizzes they own
- class analytics

### Future admin

Reserved for later. Do not implement broad admin powers in the client.

## Offline rules

Safe read data can be cached.

Mutations are written to the outbox with:
- `mutationId`
- `createdAt`
- `action`
- `payload`
- `attempts`
- `status`

The backend should make mutations idempotent using `mutationId`.

Never silently overwrite a server value with an older offline value.

## Installability

The existing project already has a basic standalone manifest and service worker. The production version will harden these later.

PWA installability and APK packaging are separate concerns:

```text
Web app → PWA install
        → Android package (later)
```

An APK must package the application itself. It should not merely launch a normal browser tab.

## Build sequence

1. Foundation
2. Backend authentication
3. App shell/design system
4. API integration
5. Student workflows
6. Teacher workflows
7. Offline sync
8. PWA hardening
9. Android APK
10. Security/testing/release
