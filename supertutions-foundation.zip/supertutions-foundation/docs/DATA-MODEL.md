# Google Sheets Data Model v1

Use separate sheets for separate domains. Avoid putting everything into one giant sheet.

## Users

| Column | Meaning |
|---|---|
| id | Stable user ID |
| role | student / teacher |
| name | Display name |
| email | Login identifier |
| passwordHash | Server-side credential hash, never plaintext |
| classId | Primary class/batch for students |
| status | active / disabled |
| createdAt | ISO timestamp |
| updatedAt | ISO timestamp |

## Classes

| Column | Meaning |
|---|---|
| id | Stable class ID |
| name | Display name |
| subject | Subject |
| teacherId | Owner teacher |
| status | active / archived |
| createdAt | ISO timestamp |

## Enrollments

| Column | Meaning |
|---|---|
| id | Stable enrollment ID |
| classId | Class |
| studentId | Student |
| status | active / paused / ended |
| createdAt | ISO timestamp |

## Attendance

| Column | Meaning |
|---|---|
| id | Stable attendance ID |
| classId | Class |
| studentId | Student |
| date | YYYY-MM-DD |
| status | present / absent / late |
| markedBy | Teacher ID |
| updatedAt | ISO timestamp |

## Homework

| Column | Meaning |
|---|---|
| id | Stable homework ID |
| classId | Class |
| title | Homework title |
| description | Instructions |
| dueAt | ISO timestamp |
| createdBy | Teacher ID |
| updatedAt | ISO timestamp |

## Quiz attempts

| Column | Meaning |
|---|---|
| id | Attempt ID |
| quizId | Quiz |
| studentId | Student |
| score | Numeric score |
| submittedAt | ISO timestamp |
| mutationId | Idempotency key |

## Design rules

- IDs are stable and never derived from row numbers.
- Dates are stored in ISO format.
- `createdAt` and `updatedAt` are timestamps.
- Row numbers are implementation details, not public IDs.
- Backend filters rows by authenticated user/role before returning them.
